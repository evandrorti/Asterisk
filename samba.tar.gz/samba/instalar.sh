#Criado por Evandro
#09/09/2021
#!/bin/bash

apt -y install samba
mv /etc/samba/smb.conf /etc/samba/smb.conf.bkp

echo "#Global parameters
[global]
        workgroup = CENTRAL
	log file = /var/log/samba/log.%m
	max log size = 1000
	server role = standalone server

[netlogon]
        path = /var/lib/samba/sysvol/central.intra/scripts
        read only = No


[sysvol]
        path = /var/lib/samba/sysvol
        read only = No


[Asterisk]
        path = /Asterisk
        read only = No
        guest ok = Yes
" > /etc/samba/smb.conf
