#!/bin/bash
source /etc/asterisk/script/dados.txt
caminho="/etc/asterisk/script"
ramalOrigem=$1
idCliente=$2
if [ ! -z "$ramalOrigem" ]
then
	idUsuario=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT associacaoRamalXUsuarioUsuarioCodigo FROM tabelaAssociacaoRamalXUsuario WHERE associacaoRamalXUsuarioRamal LIKE '$ramalOrigem' GROUP BY associacaoRamalXUsuarioUsuarioCodigo"`
	if [ ! -z "$idUsuario" ]
	then
		 if [ ! -z "$idCliente" ]
       		 then
			ipAtendente=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT associacaoIPAtendenteXUsuarioIP  FROM tabelaAssociacaoIPAtendenteXUsuario WHERE associacaoIPAtendenteXUsuarioUsuarioCodigo LIKE '$idUsuario' LIMIT 1"`
			porta="20160"
			 if [ ! -z "$ipAtendente" ]
	                 then
				clienteImodulo=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT clienteImoduloCodigo FROM tabelaClientes WHERE clienteID LIKE '$idCliente' LIMIT 1"`
				if [  $clienteImodulo -gt 0 ]
		                then
#					echo "entrou imodulo!"
					echo "$caminho/integracaoImodulo.py $ipAtendente $porta $clienteImodulo"
					python $caminho/integracaoImodulo.py $ipAtendente $porta $clienteImodulo
					exit 0
				else
					echo "sem conta imodulo cadastrado"
				fi
			else
				echo "sem ip de atendente"
			fi
		else
			echo "sem idCliente"
			exit 0
		fi
	else
		echo "sem usuario"
		exit 0
	fi
else
	echo "sem origem"
	exit 0
fi
