#!/usr/bin/expect

set USUARIO "maestro"
set SENHA "m4estr02020"
set ramalOrigem [lindex $argv 0]
set contexto [lindex $argv 1]
set codigoImodulo [lindex $argv 2]
set destino 00
spawn telnet localhost 5038

expect "Manager"
send -- "Action:Login\rUsername: $USUARIO\rSecret: $SENHA\rEvents: off\r\n"
send -- "Action: Originate\rChannel: SIP/$ramalOrigem\rExten: $destino\rCallerID: $ramalOrigem\rContext: $contexto\rPriority: 1\rAsync: yes\r\n"
send -- "Action: Logoff\r\n"
expect eof

