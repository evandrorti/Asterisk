#!/usr/bin/env python3
import socket
import sys

#dados = []
#dados = input().split(" ")

ip = str(sys.argv[1])
porta = int(sys.argv[2])
codigoImodulo = str(sys.argv[3])
codigoImodulo="isocket:"+codigoImodulo
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.settimeout(1)
clientSocket.connect((ip,porta))
clientSocket.send(codigoImodulo.encode());
