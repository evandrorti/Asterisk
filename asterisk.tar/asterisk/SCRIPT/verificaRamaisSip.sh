#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh
HOST=10.0.0.185
totalLinhas=`asterisk -rx 'sip show peers' | wc -l`
linhasHead=$(($totalLinhas-1))
linhasTail=$(($linhasHead-1))

TABLE="tabelaRamaisSip"
asterisk -rx 'sip show peers' | head -n$linhasHead | tail -n$linhasTail | grep -vie "-recept" > /etc/asterisk/SCRIPT/verificaRamaisSip.log 
linhas=0
while read ramal
do
	ESTADO=0
	RAMAL=`echo $ramal | awk '{print $1}' | cut -d '/' -f1`
	ESTADO=`echo $ramal | grep -e 'OK (' | grep -e 'ms)'  | wc -l`
	if [[ ${#RAMAL} -ge 4 ]]
	then

		verificaSeRamalExiste=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT ramalSIPRamal from $TABLE WHERE ramalSIPRamal=\"$RAMAL\" GROUP BY \"$RAMAL\"" | wc -l`
		if [[ $verificaSeRamalExiste -eq 1 ]]
		then
			if [[ ${ESTADO} -eq 1 ]]
	        	then
				verificaEstado=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT ramalSIPEstado from $TABLE WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=1" | wc -l`
				if [[ $verificaEstado -eq 1 ]]
				then
					mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET ramalSIPUltimoTeste=NOW() WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=1"
			
				else
				 	 mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET ramalSIPEncerrado=NOW() WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=0"
	
					 mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (ramalSIPRamal,ramalSIPEstado,ramalSIPParceiroID,ramalSIPClienteID) VALUES (\"$RAMAL\",1,\"${RAMAL:0:2}\",${RAMAL:2:2})"
				fi
			else
				verificaEstado=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT ramalSIPEstado from $TABLE WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=1" | wc -l`
                	        if [[ $verificaEstado -eq 1 ]]
                        	then	
			 		 mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET ramalSIPEncerrado=NOW() WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=1"
					 mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (ramalSIPRamal,ramalSIPParceiroID,ramalSIPClienteID) VALUES (\"$RAMAL\",\"${RAMAL:0:2}\",${RAMAL:2:2})"
				else
					verificaEstado=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT ramalSIPEstado from $TABLE WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=0" | wc -l`
					if [[ $verificaEstado -eq 1 ]]
	                        	then
					 	mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET ramalSIPUltimoTeste=NOW() WHERE ramalSIPRamal=\"$RAMAL\" AND ramalSIPEncerrado=\"0000-00-00 00:00:00\" AND ramalSIPEstado=0"
					else
						mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (ramalSIPRamal,ramalSIPParceiroID,ramalSIPClienteID) VALUES (\"$RAMAL\",\"${RAMAL:0:2}\",${RAMAL:2:2})"
					fi
				fi
			fi
		
		else
			mysql -u$USER -p$PASS -h$HOST $DB -se "DELETE FROM $TABLE WHERE ramalSIPEstado=\"$RAMAL\")"
		fi
	fi
	linhas=$((linhas+1))
	echo $linhas
	sleep 1
done < /etc/asterisk/SCRIPT/verificaRamaisSip.log
echo "t" >> "/etc/asterisk/SCRIPT/teste.txt"
