#!/bin/bash
#source /etc/asterisk/script/dados.txt
source /etc/asterisk/SCRIPT/dados.sh
HOST=10.0.0.185
caminho="/etc/asterisk/SCRIPT"

ramalOrigem=$1
idCliente=$2
if [ ! -z "$ramalOrigem" ]
then
	idUsuario=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT associacaoRamalXUsuarioUsuarioCodigo FROM tabelaAssociacaoRamalXUsuario WHERE associacaoRamalXUsuarioRamal LIKE '$ramalOrigem' GROUP BY associacaoRamalXUsuarioUsuarioCodigo"`
	echo $idUsuario
	if [ ! -z "$idUsuario" ]
	then
		if [ ! -z "$idCliente" ]
		then
			monitorID=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT associacaoMesaXUsuarioMesa FROM tabelaAssociacaoMesaXUsuario WHERE associacaoMesaXUsuarioUsuarioCodigo LIKE '$idUsuario' LIMIT 1"`
#			screenStyleID=$3
#screenStyleID="34669"
#			responseFormat=$4
			responseFormat="Text"
			clienteCodigo=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT clienteCodigo FROM tabelaClientes WHERE clienteID LIKE '$idCliente' LIMIT 1"`
			while IFS=$'\t' read integracaoCodigo integracaoClienteCodigo integracaoString integracaoIP integracaoPorta integracaoUsuario integracaSenha integracaoScreenID;

			do
#				integracaoString=$(echo "$integracaoString" | sed "s/ /%/g")
				URL="http://"
			 	URL="${URL}$integracaoIP:$integracaoPorta"
				URL="${URL}/Interface/VirtualMatrix/ShowPublicScreenView?"
				URL="${URL}MonitorID=$monitorID&"
				URL="${URL}ScreenStyleID=$integracaoScreenID&"
				URL="${URL}ScreenViewName=$integracaoString&"
				URL="${URL}ResponseFormat=$responseFormat&"
				URL="${URL}AuthUser=$integracaoUsuario&"
				URL="${URL}AuthPass=$integracaSenha"
				curl $URL
				echo $URL
			done < <(mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT * FROM tabelaIntegracaoSI WHERE integracaoClienteCodigo LIKE $clienteCodigo")
			exit 0
		else
			echo "sem idCliente"
			exit 0
		fi
	else
		echo "sem usuario"
		exit 0
	fi
else
	echo "sem origem"
	exit 0
fi
