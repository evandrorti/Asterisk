#CRIADO POR EVANDRO
#02-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh
caminho="/etc/asterisk/SCRIPT"
RAMAL_ORIGEM=${1}
RAMAL_DESTINO=${2}
DATA=${3}
UNIQUEID=${4}
ANO=${5}
MES=${6}
DIA=${7}
IDPARCEIRO=${8}
IDCLIENTE=${9}
TIPO=${10}
MIX=${11}
NUMERO_DESTINO=${12}
CLIENTEID=$IDPARCEIRO$IDCLIENTE
if [[ ${#NUMERO_DESTINO} -gt 11 ]]
then
	NUMERO_DESTINO=${NUMERO_DESTINO:10}
fi
IDUSUARIO=$(mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "

                                                        SELECT
                                                                associacaoRamalXUsuarioUsuarioCodigo
                                                        FROM
                                                              tabelaAssociacaoRamalXUsuario
                                                        WHERE
                                                              associacaoRamalXUsuarioRamal
                                                              LIKE '$RAMAL_ORIGEM'

                                                        ")
#IDUSUARIO=0
if [[ $IDUSUARIO -gt 0 ]]
then
        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrUsuarioCodigo,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$NUMERO_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX',$IDUSUARIO,'$CLIENTEID')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrUsuarioCodigo,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$NUMERO_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX',$IDUSUARIO,'$CLIENTEID')"



else
        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$NUMERO_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$NUMERO_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')"

fi

