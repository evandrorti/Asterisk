#CRIADO POR EVANDRO
#02-09-2021
#!/bin/bash


source /etc/asterisk/SCRIPT/dados.sh
caminho="/etc/asterisk/SCRIPT"
RAMAL_ORIGEM=${1}
RAMAL_DESTINO=${2}
DATA=${3}
UNIQUEID=${4}
ANO=${5}
MES=${6}
DIA=${7}
IDPARCEIRO=${8}
IDCLIENTE=${9}
TIPO=${10}
MIX=${11}
CLIENTEID=$IDPARCEIRO$IDCLIENTE
IDUSUARIO=$(mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "

                                                        SELECT
                                                                associacaoRamalXUsuarioUsuarioCodigo
                                                        FROM
                                                              tabelaAssociacaoRamalXUsuario
                                                        WHERE
                                                                associacaoRamalXUsuarioRamal
                                                                LIKE '$RAMAL_ORIGEM'

                                                        ")
#IDUSUARIO=0
if [[ $IDUSUARIO -gt 0 ]]
then
#        echo "entrou"
        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrUsuarioCodigo,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX',$IDUSUARIO,'$CLIENTEID')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrUsuarioCodigo,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX',$IDUSUARIO,'$CLIENTEID')"

        validaLigacao=$(
                mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "SELECT COUNT(cdrCodigo) FROM $tableRapido WHERE cdrUsuarioCodigo LIKE $IDUSUARIO  AND cdrFim='0000-00-00 00:00:00' and cdrInicio between now() - interval 10 minute and now()"
                )
#        echo "valida: $validaLigacao"

#        echo  mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "SELECT COUNT(cdrCodigo) FROM $tableRapido WHERE cdrUsuarioCodigo LIKE $IDUSUARIO  AND cdrFim like '0000-00-00 00:00:00'"


        if [[ $validaLigacao -le 1 ]]
        then
#                echo "entrou"
		/bin/bash $caminho/integracaoSigmaImagem.sh "${RAMAL_ORIGEM}" "${CLIENTEID}"
                /bin/bash $caminho/integracaoImodulo.sh "${RAMAL_ORIGEM}" "${CLIENTEID}"
#                echo "/bin/bash $caminho/integracaoSigmaImagem.sh "${RAMAL_ORIGEM}" "${CLIENTEID}""
#                echo "/bin/bash $caminho/integracaoImodulo.sh "${RAMAL_ORIGEM}" "${CLIENTEID}""
        fi
else
        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTEID')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTEID')"



#echo "mysql -u$USER -p$PASS -h$HOST $DB -se \"INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTEID')\""

#echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"

#echo "mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se \"INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTEID')\""

fi

