#!/bin/bash
source /etc/asterisk/script/dados.txt
ramalOrigem=$1
idCliente=$2
if [ ! -z "$ramalOrigem" ]
then
	stringID=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT ramalClienteStringID from tabelaRamaisCliente where ramalClienteRamal like '$ramalOrigem' LIMIT 1"`
	if [ ! -z "$stringID" ]
	then
		clienteCodigo=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT ramalClienteClienteCodigo from tabelaRamaisCliente where ramalClienteRamal like '$ramalOrigem' LIMIT 1"`
		if [ ! -z "$clienteCodigo" ]
	        then
			while IFS=$'\t' read videowallCodigo videowallMonitorID videowallQuadroAtual videowallLimiteQuadros videowallUsuario videowallSenha videowallIP videowallPorta
			do
				if [ $videowallQuadroAtual -lt $videowallLimiteQuadros ] 
				then
					mysql -u$USER -p$PASS -h $HOST $DB -se "
											UPDATE
												tabelaVideowall
											SET 
												videowallQuadroAtual=videowallQuadroAtual+1,
												videowallPosicao=videowallPosicao+1
											WHERE
												videowallMonitorID
											LIKE
												 '$videowallMonitorID'
										"
				else
					mysql -u$USER -p$PASS -h $HOST $DB -se "
                                                                                        UPDATE
                                                                                                tabelaVideowall
                                                                                        SET
                                                                                                videowallQuadroAtual=1,
												videowallPosicao=videowallPosicao+1
                                                                                        WHERE
											        videowallMonitorID
                                                                                        LIKE
                                                                                                 '$videowallMonitorID'
                                                                                "

				fi
				DoNotReplaceSameObj="true"
				responseFormat="Text"
				ObjectType="0"
				URL="http://"
				URL="${URL}${videowallIP}"
				URL="${URL}:${videowallPorta}"
				URL="${URL}/Interface/VirtualMatrix/ShowObject?"
				URL="${URL}MonitorID=$videowallMonitorID&"
				URL="${URL}SpotNumber=${videowallQuadroAtual}&"
				URL="${URL}ObjectType=${ObjectType}&"
				URL="${URL}ObjectName=${stringID}&"
				URL="${URL}DoNotReplaceSameObj=${DoNotReplaceSameObj}&"
				URL="${URL}responseFormat=${responseFormat}&"
				URL="${URL}AuthUser=${videowallUsuario}&"
				URL="${URL}AuthPass=${videowallSenha}"

				echo $URL
				curl $URL
			done < <(
				mysql -u$USER -p$PASS -h $HOST $DB -se "	SELECT 
											videowallCodigo, videowallMonitorID, videowallQuadroAtual, videowallLimiteQuadros, videowallUsuario, videowallSenha, videowallIP, videowallPorta
										FROM
											tabelaVideowall
										WHERE 
											videowallCodigo IN
											(
												SELECT 
													associacaoClienteXVideowallVideowallCodigo
												FROM
													tabelaAssociacaoClientesXVideowall
												WHERE
													associacaoClienteXVideowallClienteCodigo
													LIKE $clienteCodigo
											)
										ORDER BY
											videowallPosicao,videowallQuadroAtual
											LIMIT 1"
				)
			#			monitorID=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT associacaoMesaXUsuarioMesa FROM tabelaAssociacaoMesaXUsuario WHERE associacaoMesaXUsuarioUsuarioCodigo LIKE '$idUsuario' LIMIT 1"`
#			screenStyleID=$3
#screenStyleID="34669"
#			responseFormat=$4
#			responseFormat="Text"
#			clienteCodigo=`mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT clienteCodigo FROM tabelaClientes WHERE clienteID LIKE '$idCliente' LIMIT 1"`
#			while IFS=$'\t' read integracaoCodigo integracaoClienteCodigo integracaoString integracaoIP integracaoPorta integracaoUsuario integracaSenha integracaoScreenID;
#			do
#				integracaoString=$(echo "$integracaoString" | sed "s/ /%/g")
#				URL="http://"
#			 	URL="${URL}$integracaoIP:$integracaoPorta"
#				URL="${URL}/Interface/VirtualMatrix/ShowPublicScreenView?"
#				URL="${URL}MonitorID=$monitorID&"
#				URL="${URL}ScreenStyleID=$integracaoScreenID&"
#				URL="${URL}ScreenViewName=$integracaoString&"
#				URL="${URL}ResponseFormat=$responseFormat&"
#				URL="${URL}AuthUser=$integracaoUsuario&"
#				URL="${URL}AuthPass=$integracaSenha"
#				curl $URL
#				echo $URL
#			done < <(mysql -u$USER -p$PASS -h $HOST $DB -se "SELECT * FROM tabelaIntegracaoSI WHERE integracaoClienteCodigo LIKE $clienteCodigo")
		else
			echo "sem clienteCodigo"
			exit 0
		fi
	else
		echo "sem ramal de origem cadastrado"
		exit 0
	fi
else
	echo "sem ramal de origem"
	exit 0
fi
