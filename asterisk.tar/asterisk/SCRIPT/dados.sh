#CRIADO POR EVANDRO
#01-09-2021

USER="maestro"
PASS="m4estr02020"
DB="maestro"
HOST="localhost"
TABLE="CDR"

userRapido="maestro"
passRapido="m4estr02020"
dbRapido="maestro"
hostRapido="10.0.0.185"
tableRapido="cdrRapido"



