#CRIADO POR EVANDRO
#02-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh

RAMAL_ORIGEM=${1}
NOME_FILA=${2}
DATA=${3}
UNIQUEID=${4}
ANO=${5}
MES=${6}
DIA=${7}
IDPARCEIRO=${8}
IDCLIENTE=${9}
TIPO=${10}
MIX=${11}
CLIENTID=$IDPARCEIRO$IDCLIENTE

        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrFila,cdrInicio,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$NOME_FILA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTID')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrFila,cdrInicio,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix,cdrClienteClienteID) values ('$RAMAL_ORIGEM','$NOME_FILA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDCLIENTE','$TIPO','$MIX','$CLIENTID')"


