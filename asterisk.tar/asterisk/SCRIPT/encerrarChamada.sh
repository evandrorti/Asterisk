#CRIADO POR EVANDRO
#01-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh

UNIQUEID=$1
DATA=$2
cdrFim=0
NAO_ATENDIDA=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrEspera FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
controle=0
ESPERA="0000-00-00 00:00:00"
        if [ "$NAO_ATENDIDA" == "$ESPERA" ] ; then
		while [[ "$DATA != $cdrFim" && $controle < 10 ]]
                do
			mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrFim='$DATA',cdrEspera='$DATA',cdrNaoAtendida=1 WHERE cdrUniqueID like '$UNIQUEID'"
			cdrFim=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrFim FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
			controle=$((controle+1))
		done
        else
		while [[ "$DATA != $cdrFim" && $controle < 10 ]]
		do
                	mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrFim='$DATA' WHERE cdrUniqueID like '$UNIQUEID'"
			cdrFim=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrFim FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
			controle=$((controle+1))
		done
        fi

NAO_ATENDIDA=` mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "SELECT cdrEspera FROM $tableRapido WHERE cdrUniqueID like '$UNIQUEID'"`
ESPERA="0000-00-00 00:00:00"
controle=0
        if [ "$NAO_ATENDIDA" == "$ESPERA" ] ; then
		while [[ "$DATA != $cdrFim" && $controle < 10 ]]
		do
	                mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrFim='$DATA',cdrEspera='$DATA',cdrNaoAtendida=1 WHERE cdrUniqueID like '$UNIQUEID'"
			cdrFim=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrFim FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
			controle=$((controle+1))
		done
        else
		while [[ "$DATA != $cdrFim" && $controle < 10 ]]
		do
	                mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrFim='$DATA' WHERE cdrUniqueID like '$UNIQUEID'"
			cdrFim=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrFim FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
			controle=$((controle+1))
		done
        fi

echo 0
