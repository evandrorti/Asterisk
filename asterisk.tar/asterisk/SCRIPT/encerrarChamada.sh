#CRIADO POR EVANDRO
#01-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh

UNIQUEID=$1
DATA=$2

NAO_ATENDIDA=`mysql -u$USER -p$PASS -h$HOST $DB -se "SELECT cdrEspera FROM $TABLE WHERE cdrUniqueID like '$UNIQUEID'"`
ESPERA="0000-00-00 00:00:00"
        if [ "$NAO_ATENDIDA" == "$ESPERA" ] ; then
                mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrFim='$DATA',cdrEspera='$DATA',cdrNaoAtendida=1 WHERE cdrUniqueID like '$UNIQUEID'"
        else
                mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrFim='$DATA' WHERE cdrUniqueID like '$UNIQUEID'"
        fi

NAO_ATENDIDA=` mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "SELECT cdrEspera FROM $tableRapido WHERE cdrUniqueID like '$UNIQUEID'"`
ESPERA="0000-00-00 00:00:00"
        if [ "$NAO_ATENDIDA" == "$ESPERA" ] ; then
                mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrFim='$DATA',cdrEspera='$DATA',cdrNaoAtendida=1 WHERE cdrUniqueID like '$UNIQUEID'"
        else
                mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrFim='$DATA' WHERE cdrUniqueID like '$UNIQUEID'"
        fi

