#CRIADO POR EVANDRO
#02-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh

UNIQUEID=${1}
DATA=${2}
ATENDENTE=${3}


ramalAtendente=$(mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "

                                                         SELECT
                                                                associacaoRamalXUsuarioUsuarioCodigo
                                                         FROM
                                                              tabelaAssociacaoRamalXUsuario
                                                         WHERE
                                                                 associacaoRamalXUsuarioRamal
                                                                 LIKE '$ATENDENTE'

                                                        ")

if [[ $ramalAtendente -gt 0 ]]
then
        echo "mysql -u$USER -p$PASS -h$HOST $DB -se 'UPDATE $TABLE SET cdrEspera='$DATA' WHERE cdrUniqueID like '$UNIQUEID''"
        mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrEspera='$DATA',cdrDestino='$ATENDENTE',cdrUsuarioCodigo=$ramalAtendente WHERE cdrUniqueID like $UNIQUEID"


        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrEspera='$DATA',cdrDestino='$ATENDENTE',cdrUsuarioCodigo=$ramalAtendente WHERE cdrUniqueID like $UNIQUEID"
        ramalOrigem=$ATENDENTE
        idCliente=`mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "SELECT cdrClienteClienteID FROM $tableRapido WHERE cdrUniqueID like $UNIQUEID"`

        validaLogin=3
        if [[ $validaLigacao -le 1 ]]
        then


                /bin/bash /etc/asterisk/SCRIPT/integracaoSigmaImagem.sh "$ramalOrigem" "$idCliente" &
                /bin/bash /etc/asterisk/SCRIPT/integracaoImodulo.sh "$ramalOrigem" "$idCliente" &
        fi
else
        echo "mysql -u$USER -p$PASS -h$HOST $DB -se 'UPDATE $TABLE SET cdrEspera='$DATA' WHERE cdrUniqueID like '$UNIQUEID''"
        mysql -u$USER -p$PASS -h$HOST $DB -se "UPDATE $TABLE SET cdrEspera='$DATA',cdrDestino='$ATENDENTE' WHERE cdrUniqueID like $UNIQUEID"


        echo "mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se 'UPDATE $tableRapido SET cdrEspera='$DATA' WHERE cdrUniqueID like '$UNIQUEID''"
        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "UPDATE $tableRapido SET cdrEspera='$DATA',cdrDestino='$ATENDENTE' WHERE cdrUniqueID like $UNIQUEID"
fi

