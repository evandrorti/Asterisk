#!/bin/bash
#CRIADO POR EVANDRO 08/10/2021

source /etc/asterisk/SCRIPT/dados.sh
data=`date --date="yesterday" +"%Y%m%d"`
dataBackup=`date --date="yesterday" +"%Y/%m/%d"`

caminhoAudios="/Asterisk/Gravacao/*/*/$dataBackup"
caminhoBackup=/media/Storage

cp --parents -vR $caminhoAudios $caminhoBackup/
#rm -vrf $caminhoAudios
