#!/bin/bash
mysql -umaestro -pm4estr02020 maestro -h 10.0.0.185 -se "delete from cdrRapido where (SECOND(timediff(now(),cdrEspera)) + (MINUTE(timediff(now(),cdrEspera))*60)) > 300"
