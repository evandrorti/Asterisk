#CRIADO POR EVANDRO
#01-09-2021
#!/bin/bash

source /etc/asterisk/SCRIPT/dados.sh

RAMAL_DESTINO=${1}
RAMAL_ORIGEM=${2}
DATA=${3}
UNIQUEID=${4}
ANO=${5}
MES=${6}
DIA=${7}
IDPARCEIRO=${8}
TIPO=${9}
MIX=${10}

        mysql -u$USER -p$PASS -h$HOST $DB -se "INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')"

        mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se "INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')"

#echo "mysql -u$USER -p$PASS -h$HOST $DB -se \"INSERT INTO $TABLE (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')\""

#echo "mysql -u$userRapido -p$passRapido -h$hostRapido $dbRapido -se \"INSERT INTO $tableRapido (cdrOrigem,cdrDestino,cdrInicio,cdrEspera,cdrUniqueID,cdrAno,cdrMes,cdrDia,cdrCodigoParceiro,cdrCodigoCliente,cdrTipo,cdrMix) values ('$RAMAL_ORIGEM','$RAMAL_DESTINO','$DATA','$DATA','$UNIQUEID',$ANO,$MES,$DIA,'$IDPARCEIRO','$IDPARCEIRO','$TIPO','$MIX')\""

